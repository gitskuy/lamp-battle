
// Java program to illustrate
// ThreadPool
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Task class to be executed (Step 1)
public class Client implements Runnable {
  private String threadChooser;
  private String input;

  public Client(String s, String in) {
    threadChooser = s;
    input = in;
  }

  // Prints task name and sleeps for 1s
  // This Whole process is repeated 5 times
  public void run() {
    try {
      if (threadChooser.equalsIgnoreCase("pesanan")) {
        Date d = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("hh:mm:ss");
        FileWriter myWriter = new FileWriter("filethread.txt");
        myWriter.write(input);
        myWriter.close();
        System.out.println("Pesanan: " + input + " is made at " + ft.format(d));

        // prints the initialization time for every task
      } else if (threadChooser.equals("kirim")) {
        Date d = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("hh:mm:ss");
        FileWriter myWriter = new FileWriter("kirim.txt");
        myWriter.write(input);
        myWriter.close();
        System.out.println("Tujuan: " + input + " is made at " + ft.format(d));
        // prints the execution time for every task
      }
      Thread.sleep(5000);

    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
}