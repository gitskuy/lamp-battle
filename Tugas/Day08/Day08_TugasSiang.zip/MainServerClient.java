
// Java program to illustrate
// ThreadPool
import java.io.FileWriter; // Import the FileWriter class
import java.io.IOException; // Import the IOException class to handle
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Task class to be executed (Step 1)
public class MainServerClient {

  static final int MAX_T = 1;

  public static void main(String[] args) {
    // creates five tasks
    Date d = new Date();
    SimpleDateFormat ft = new SimpleDateFormat("hh:mm:ss");
    Runnable r1 = new Client("pesanan", "nasi goreng,bubur ayam");
    Runnable r2 = new Client("kirim", "condet");
    Runnable r3 = new Client("pesanan", "nasi goreng,bubur ayam,es teh manis");
    Runnable r4 = new Client("kirim", "bekasi");
    Runnable printpesanan = new Server();
    // creates a thread pool with MAX_T no. of
    // threads as the fixed pool size(Step 2)
    ExecutorService pool = Executors.newFixedThreadPool(MAX_T);

    // runs the and execute client server
    r1.run();
    r2.run();
    pool.execute(printpesanan);
    pool.execute(r3);
    pool.execute(r4);
    pool.execute(printpesanan);

    // pool.execute(r1);
    // pool.execute(r2);
    // printpesanan.run();
    // pool.execute(r3);
    // pool.execute(r4);
    // printpesanan.run();

    // pool shutdown ( Step 4)
    pool.shutdown();
  }
}