import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;
import java.util.Properties;
import java.util.Scanner;

public class Server {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Scanner in = new Scanner(System.in);
        int flag = 0;
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/sonoo?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","okeh1234");
        //here sonoo is the database name, root is the username and root is the password
        Statement stmt = con.createStatement();


        while(flag == 0){
            System.out.println("1.Initialize server socket");
            System.out.println("2.Show All Data");
            System.out.println("3.Exit");
            Integer input = Integer.parseInt(in.nextLine());
            if(input == 1){
                readinput("/home/ahmad/DANA/belajarbareng/ServerClientData/src/config.properties",stmt);
            }if(input == 2){
                show(stmt);
            }if(input == 3){
                flag = 1;
            }
        }
    }

    private static void readinput(String args,Statement stmt) {
        try {
            Properties prop = new Properties();
            InputStream input = null;
            input = new FileInputStream(args);
            // load a properties file
            prop.load(input);
            String socket = prop.getProperty("port");
            ServerSocket ss = new ServerSocket(Integer.parseInt(socket));
            Socket s = ss.accept();
            DataInputStream dis = new DataInputStream(s.getInputStream());

            int flag = 0;
            while (flag == 0) {
                String str = (String) dis.readUTF();
                if (str.equals("exit")) {
                    flag = 1;
                } else {
                    insertData(str,stmt);
                    System.out.println("Client says: " + str);
                }
            }
            ss.close();

        } catch (Exception e) {
            System.out.println(e);

        }
    }
    private static void insertData(String fromclient,Statement stmt) throws SQLException {
        String[] fc = fromclient.split(",");

        System.out.println("ID");
        int id = Integer.parseInt(fc[0]);
        System.out.println("Name?");
        String name = fc[1];
        System.out.println("Age?");
        int age = Integer.parseInt(fc[2]);

        stmt.executeUpdate("insert into emp(id,name,age) values ("+id+",\""+name+"\","+age+");");
        System.out.println(name + " Has Been Succesfully Inserted to Table");
        System.out.println("Table Updated");
        show(stmt);
    }
    private static void show(Statement stmt) throws SQLException {
        ResultSet rs=stmt.executeQuery("select * from emp");
        System.out.println("-----------------------------");
        while(rs.next())
            System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));

        System.out.println("-----------------------------");
    }
}